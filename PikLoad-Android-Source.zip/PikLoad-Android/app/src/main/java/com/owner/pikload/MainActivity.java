package com.owner.pikload;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity {
    // Set this to your preferred public owner name before publishing.
    private static final String OWNER_NAME = "Project Owner";

    private EditText linkInput;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        handleIncomingShare(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingShare(intent);
    }

    private void buildScreen() {
        int bg = 0xFF101521;
        int panel = 0xFF1B2433;
        int white = 0xFFF4F7FB;
        int muted = 0xFFACB8C8;
        int accent = 0xFF55C2FF;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(28));
        scroll.addView(page);

        TextView brand = new TextView(this);
        brand.setText("PikLoad");
        brand.setTextColor(accent);
        brand.setTextSize(30);
        brand.setTypeface(null, android.graphics.Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("مدير تنزيلاتك — احفظ الملفات على جهازك");
        subtitle.setTextColor(white);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(24));
        page.addView(subtitle, matchWrap());

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(roundBg(panel, 18));
        page.addView(card, matchWrap());

        TextView label = new TextView(this);
        label.setText("ألصق رابط الملف أو رابط المشاركة");
        label.setTextColor(white);
        label.setTextSize(16);
        label.setGravity(Gravity.RIGHT);
        card.addView(label, matchWrap());

        linkInput = new EditText(this);
        linkInput.setSingleLine(false);
        linkInput.setMinLines(2);
        linkInput.setTextSize(14);
        linkInput.setHint("https://...");
        linkInput.setHintTextColor(muted);
        linkInput.setTextColor(white);
        linkInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        linkInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        linkInput.setBackground(roundBg(0xFF273447, 12));
        LinearLayout.LayoutParams inputParams = matchWrap();
        inputParams.topMargin = dp(12);
        card.addView(linkInput, inputParams);

        Button paste = new Button(this);
        paste.setText("لصق الرابط");
        paste.setOnClickListener(v -> pasteFromClipboard());
        LinearLayout.LayoutParams pasteParams = matchWrap();
        pasteParams.topMargin = dp(10);
        card.addView(paste, pasteParams);

        Button download = new Button(this);
        download.setText("تنزيل إلى ذاكرة الهاتف");
        download.setTextColor(0xFF07131D);
        download.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        download.setOnClickListener(v -> startDownload());
        LinearLayout.LayoutParams downloadParams = matchWrap();
        downloadParams.topMargin = dp(10);
        card.addView(download, downloadParams);

        statusText = new TextView(this);
        statusText.setText("يدعم حالياً روابط الملفات المباشرة القابلة للتنزيل.");
        statusText.setTextColor(muted);
        statusText.setTextSize(13);
        statusText.setGravity(Gravity.RIGHT);
        statusText.setPadding(0, dp(16), 0, 0);
        card.addView(statusText, matchWrap());

        TextView help = new TextView(this);
        help.setText("روابط مشاركة PikPak تحتاج تكاملاً رسمياً مصرحاً به. هذا الإصدار لا يتجاوز Premium أو حدود الحساب، ولا يدّعي تنزيل مجلد المشاركة تلقائياً.");
        help.setTextColor(muted);
        help.setTextSize(13);
        help.setGravity(Gravity.RIGHT);
        help.setPadding(dp(4), dp(18), dp(4), dp(18));
        page.addView(help, matchWrap());

        LinearLayout about = new LinearLayout(this);
        about.setOrientation(LinearLayout.VERTICAL);
        about.setPadding(dp(16), dp(14), dp(16), dp(14));
        about.setBackground(roundBg(panel, 16));
        page.addView(about, matchWrap());

        TextView owner = new TextView(this);
        owner.setText("مالك المشروع: " + OWNER_NAME);
        owner.setTextColor(white);
        owner.setTextSize(14);
        owner.setGravity(Gravity.RIGHT);
        about.addView(owner, matchWrap());

        TextView license = new TextView(this);
        license.setText("Open Source · MIT License · الإصدار 0.1.0");
        license.setTextColor(muted);
        license.setTextSize(12);
        license.setGravity(Gravity.RIGHT);
        license.setPadding(0, dp(6), 0, 0);
        about.addView(license, matchWrap());

        setContentView(scroll);
    }

    private void startDownload() {
        String raw = linkInput.getText().toString().trim();
        if (raw.isEmpty()) {
            showStatus("ألصق رابطاً أولاً.");
            return;
        }

        Uri uri;
        try {
            uri = Uri.parse(raw);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))
                    || uri.getHost() == null) {
                throw new IllegalArgumentException("Invalid URL");
            }
        } catch (Exception e) {
            showStatus("الرابط غير صالح. تأكد أنه يبدأ بـ https:// أو http://");
            return;
        }

        if (isPikPakSharePage(uri)) {
            showStatus("هذا رابط مشاركة PikPak وليس رابط ملف مباشر. افتحه في PikPak؛ التنزيل التلقائي يحتاج تكاملاً رسمياً وصلاحية مناسبة.");
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception ignored) {
                showStatus("تعذر فتح الرابط على هذا الجهاز.");
            }
            return;
        }

        try {
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(fileNameFrom(uri));
            request.setDescription("PikLoad — التنزيل إلى مجلد Downloads/PikLoad");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "PikLoad/" + fileNameFrom(uri)
            );

            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            showStatus("بدأ التنزيل. رقم المهمة: " + id + " — ستجد الملف في Downloads/PikLoad.");
        } catch (Exception e) {
            showStatus("لم يبدأ التنزيل. قد يكون الرابط غير مباشر أو يتطلب تسجيل دخول.");
        }
    }

    private boolean isPikPakSharePage(Uri uri) {
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
        boolean pikpakHost = host.contains("pikpak") || host.contains("mypikpak") || host.contains("pickpack");
        return pikpakHost && (path.contains("s/") || path.contains("share") || path.isEmpty() || path.equals("/"));
    }

    private String fileNameFrom(Uri uri) {
        String segment = uri.getLastPathSegment();
        if (segment == null || segment.trim().isEmpty()) segment = "download-" + System.currentTimeMillis();
        try {
            segment = URLDecoder.decode(segment, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {}
        segment = segment.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (segment.length() > 100) segment = segment.substring(segment.length() - 100);
        return segment;
    }

    private void pasteFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip()) {
            ClipData data = clipboard.getPrimaryClip();
            if (data != null && data.getItemCount() > 0) {
                CharSequence text = data.getItemAt(0).coerceToText(this);
                linkInput.setText(text);
                showStatus("تم لصق الرابط.");
                return;
            }
        }
        showStatus("الحافظة فارغة.");
    }

    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (shared != null && linkInput != null) linkInput.setText(shared.toString());
        } else if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null && linkInput != null) {
            linkInput.setText(intent.getData().toString());
        }
    }

    private void showStatus(String message) {
        if (statusText != null) statusText.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private android.graphics.drawable.GradientDrawable roundBg(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }
}
