# PikLoad

**PikLoad** is an unofficial, open-source Android download manager prototype.

- Project owner: **Project Owner** (replace with your chosen public owner name before publishing).
- License: MIT.
- Package: `com.owner.pikload`.
- Minimum Android: 8.0 (API 26).

## Current functionality (v0.1.0)

- Arabic-first Android interface.
- Paste a URL from the clipboard.
- Accept a URL shared to the app from another Android app.
- Download **direct HTTP/HTTPS file URLs** using Android DownloadManager.
- Save files to `Downloads/PikLoad`.
- Show Android's download-complete notification.

## Important PikPak limitation

A PikPak share-page URL is not the same as a direct file URL. This starter app recognizes common PikPak share-page URLs and opens them in the browser. It does **not** automatically enumerate or download every file in a PikPak share.

PikPak provides Connected Apps integrations, Personal Access Tokens, MCP, CLI and (for eligible Premium accounts) WebDAV. Those integrations have their own authorization and transfer limits. A third-party app must use a supported authorization/integration path; this project does not bypass Premium, quotas, access controls, or speed limits. Do not paste your PikPak password or Personal Access Token into public issues or source code.

Before implementing automatic PikPak share downloads, obtain and follow PikPak's current developer/Connected Apps requirements and any required permission from PikPak. Do not reverse engineer private endpoints or scrape protected pages.

Official references:
- https://mypikpak.com/en-US/connect-apps-faq
- https://mypikpak.com/en-US/faq
- https://pikpak.me/en-US/policy/user-agreement/2026-03-01

## Build APK

1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

You can also build from a terminal with an installed Gradle 8.9+:

```bash
gradle assembleDebug
```

## GitHub Actions

The workflow in `.github/workflows/android.yml` builds a debug APK on every push and lets you download it from the workflow run's Artifacts section.

## Make yourself the owner

Edit `OWNER_NAME` in:

`app/src/main/java/com/owner/pikload/MainActivity.java`

Then update the owner name in this README and publish the repository under your own GitHub account. The current source says `Project Owner` as a placeholder because your preferred public owner name has not been provided.

## Roadmap

- [ ] Add official PikPak Connected Apps authorization when the supported flow and API details are available.
- [ ] List files from an authorized share, if PikPak officially permits this capability.
- [ ] Multi-select and queue downloads.
- [ ] Download history and retry controls.
- [ ] English/Arabic language switch.
